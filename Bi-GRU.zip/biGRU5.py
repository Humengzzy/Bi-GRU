
import matplotlib as mpl
mpl.use('Agg')
from keras.models import Model
from keras.layers import Dense, Dropout, Conv1D, Input,MaxPooling1D,Flatten,LeakyReLU, Activation, Convolution1D
from tensorflow.keras.optimizers import SGD, Adam, RMSprop
from group_norm import GroupNormalization
import random
import pandas as pd
import numpy as np
from keras import regularizers
from keras.metrics import binary_accuracy
from sklearn.metrics import confusion_matrix,recall_score,matthews_corrcoef,roc_curve,roc_auc_score,auc
import matplotlib.pyplot as plt
from keras.callbacks import EarlyStopping, ModelCheckpoint,ReduceLROnPlateau
import os, sys, copy, getopt, re, argparse
from sklearn.metrics import precision_recall_fscore_support
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
from keras import losses
import pickle
from scipy import interp
import keras as K
import keras
from keras.layers import LSTM, Bidirectional,GRU
from keras.models import Sequential
from keras.layers import Permute,Reshape,RepeatVector,Multiply
from keras.layers.core import Lambda

from collections import Counter
def get_NC_frequency_from_seq(seq, k, type='list'):
    '''
    The frequency of kmers is counted from the sequence.
    :param seq: input sequence
    :param k:
    :param type: if the value is "list"，then return a list of frequency according to the kmerNumber; else return a dict.
    :return:
    '''
    if type != 'list' and type != 'dict':
        print("error! Return normalize_type must be list or dict")

    counter = Counter(get_kmers(seq, k))
    frequence_list = [0 for i in range(4 ** k)]
    for key in counter.keys():
        frequence_list[key] += counter[key]
    frequence_list = list(np.array(frequence_list) / np.array(frequence_list).sum())
    if type == 'list':
        return frequence_list
    else:
        frequence_dict = dict()
        for i in range(4 ** k):
            frequence_dict[number2kmer(i, k=k)] = frequence_list[i]
        return frequence_dict
import pandas as pd
def get_RNAPhyche(phy_list=None, k=2, standardized=False):
    '''
    Get the physical and chemical properties values of RNA
    :param phy_list: the names of physical and chemical properties
    :param k:
    :param standardized: If it is True, then the ouput values is normalized.
    :return RNAPhyche:a DataFrame
    '''
    RNAPhyche = pd.DataFrame()
    if phy_list is None or phy_list == []:
        print("Use all the physical and chemical properties.")
    elif isinstance(phy_list, list):
        print("Use the physical and chemical properties " + str(phy_list))
    else:
        print("Error! Please input the correct phy_list.")

    if k == 2:
        nucleotide = ['A', 'C', 'G', 'U']
        dimer = [n1 + n2 for n1 in nucleotide for n2 in nucleotide]
        RNAPhyche['kmer'] = dimer
        RNAPhyche = RNAPhyche.set_index('kmer')

        RNAPhyche['Slide(RNA)'] = [-1.27, -1.43, -1.5, -1.36, -1.46, -1.78, -1.89, -1.5, -1.7, -1.39, -1.78, -1.43,
                                   -1.45, -1.7, -1.46, -1.27]
        RNAPhyche['Adenine_content'] = [2.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0]
        RNAPhyche['Hydrophilicity(RNA)'] = [0.04, 0.14, 0.08, 0.14, 0.21, 0.49, 0.35, 0.52, 0.1, 0.26, 0.17, 0.27, 0.21,
                                            0.48, 0.34, 0.44]
        RNAPhyche['Tilt(RNA)'] = [-0.8, 0.8, 0.5, 1.1, 1.0, 0.3, -0.1, 0.5, 1.3, 0.0, 0.3, 0.8, -0.2, 1.3, 1.0, -0.8]
        RNAPhyche['Stacking_energy(RNA)'] = [-13.7, -13.8, -14.0, -15.4, -14.4, -11.1, -15.6, -14.0, -14.2, -16.9,
                                             -11.1, -13.8, -16.0, -14.2, -14.4, -13.7]
        RNAPhyche['Twist(RNA)'] = [31.0, 32.0, 30.0, 33.0, 31.0, 32.0, 27.0, 30.0, 32.0, 35.0, 32.0, 32.0, 32.0, 32.0,
                                   31.0, 31.0]
        RNAPhyche['Entropy(RNA)'] = [-18.4, -26.2, -19.2, -15.5, -27.8, -29.7, -19.4, -19.2, -35.5, -34.9, -29.7, -26.2,
                                     -22.6, -26.2, -19.2, -18.4]
        RNAPhyche['Roll(RNA)'] = [7.0, 4.8, 8.5, 7.1, 9.9, 8.7, 12.1, 8.5, 9.4, 6.1, 12.1, 4.8, 10.7, 9.4, 9.9, 7.0]
        RNAPhyche['Purine(AG)_content'] = [2.0, 1.0, 2.0, 1.0, 1.0, 0.0, 1.0, 0.0, 2.0, 1.0, 2.0, 1.0, 1.0, 0.0, 1.0,
                                           0.0]
        RNAPhyche['Hydrophilicity(RNA)1'] = [0.023, 0.083, 0.035, 0.09, 0.11800000000000001, 0.349, 0.193,
                                             0.37799999999999995, 0.048, 0.146, 0.065, 0.16, 0.11199999999999999, 0.359,
                                             0.22399999999999998, 0.389]
        RNAPhyche['Enthalpy(RNA)1'] = [-6.82, -11.4, -10.48, -9.38, -10.44, -13.39, -10.64, -10.48, -12.44, -14.88,
                                       -13.39, -11.4, -7.69, -12.44, -10.44, -6.82]
        RNAPhyche['GC_content'] = [0.0, 1.0, 1.0, 0.0, 1.0, 2.0, 2.0, 1.0, 1.0, 2.0, 2.0, 1.0, 0.0, 1.0, 1.0, 0.0]
        RNAPhyche['Entropy(RNA)1'] = [-19.0, -29.5, -27.1, -26.7, -26.9, -32.7, -26.7, -27.1, -32.5, -36.9, -32.7,
                                      -29.5, -20.5, -32.5, -26.9, -19.0]
        RNAPhyche['Rise(RNA)'] = [3.18, 3.24, 3.3, 3.24, 3.09, 3.32, 3.3, 3.3, 3.38, 3.22, 3.32, 3.24, 3.26, 3.38, 3.09,
                                  3.18]
        RNAPhyche['Free_energy(RNA)'] = [-0.9, -2.1, -1.7, -0.9, -1.8, -2.9, -2.0, -1.7, -2.3, -3.4, -2.9, -2.1, -1.1,
                                         -2.1, -1.7, -0.9]
        RNAPhyche['Keto(GT)_content'] = [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 2.0, 2.0, 1.0, 1.0, 1.0, 2.0]
        RNAPhyche['Free_energy(RNA)1'] = [-0.93, -2.24, -2.08, -1.1, -2.11, -3.26, -2.36, -2.08, -2.35, -3.42, -3.26,
                                          -2.24, -1.33, -2.35, -2.11, -0.93]
        RNAPhyche['Enthalpy(RNA)'] = [-6.6, -10.2, -7.6, -5.7, -10.5, -12.2, -8.0, -7.6, -13.3, -14.2, -12.2, -10.2,
                                      -8.1, -10.2, -7.6, -6.6]
        RNAPhyche['Guanine_content'] = [0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 1.0, 1.0, 2.0, 1.0, 0.0, 0.0, 1.0, 0.0]
        RNAPhyche['Shift(RNA)'] = [-0.08, 0.23, -0.04, -0.06, 0.11, -0.01, 0.3, -0.04, 0.07, 0.07, -0.01, 0.23, -0.02,
                                   0.07, 0.11, -0.08]
        RNAPhyche['Cytosine_content'] = [0.0, 1.0, 0.0, 0.0, 1.0, 2.0, 1.0, 1.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0]
        RNAPhyche['Thymine_content'] = [0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 2.0]
        RNAPhyche['Base_stacking_energy'] = [1.30, 1.73, 1.51, 1.33, 1.10, 1.51, 1.20, 1.15, 2.07, 2.22, 1.37, 1.11,
                                             1.33, 0.85, 0.77, 1.75]
        RNAPhyche = RNAPhyche[phy_list]

    else:
        print("Error! Please input the correct value of k.")

    if standardized:
        for col in RNAPhyche.columns:
            RNAPhyche[col] = (RNAPhyche[col] - RNAPhyche[col].mean()) / RNAPhyche[col].std()
    return RNAPhyche
nuc2num_dict = {'A': 0, 'C': 1, 'G': 2, 'U': 3}
num2nuc_dict = {0: 'A', 1: 'C', 2: 'G', 3: 'U'}
def get_kmers(seq, k):  # extract kmers according to the order of the the sequence
    kmers = []
    tmp = 0
    for i in range(k - 1):
        tmp += nuc2num_dict[seq[i]] * (4 ** (k - i - 2))

    for i in range(len(seq) - k + 1):
        tmp = tmp % (4 ** (k - 1)) * 4 + nuc2num_dict[seq[i + k - 1]]
        kmers.append(tmp)
    return kmers
def kmer2number(kmer):  # Convert kmer to corresponding number，for example, 'AAG' -> 2
    k = len(kmer)
    res = 0
    for i in range(k):
        res += nuc2num_dict[kmer[i]] * (4 ** (k - i - 1))
    return res
def number2kmer(num, k=0):  # Convert the number to corresponding kmer，for example, 2 -> 'G'(k=0), or 2 -> 'AAG'(k=3)
    kmer_list = []
    while num != 0:
        remainder = num % 4
        num = int(num / 4)
        kmer_list.insert(0, num2nuc_dict[remainder])
    if k != 0:
        if k >= len(kmer_list):
            for i in range(k - len(kmer_list)):
                kmer_list.insert(0, 'A')
        else:
            print("error! k is less than the length of kmer_list.")
    return "".join(kmer_list)

# di_phy_list = ['Rise(RNA)', 'Roll(RNA)', 'Shift(RNA)', 'Slide(RNA)', 'Tilt(RNA)', 'Twist(RNA)', 'Enthalpy(RNA)1',
#                'Entropy(RNA)', 'Stacking_energy(RNA)', 'Free_energy(RNA)']
#di_phy_list = ['Rise(RNA)', 'Roll(RNA)', 'Shift(RNA)', 'Slide(RNA)', 'Tilt(RNA)', 'Twist(RNA)']
di_phy_list = ['Slide(RNA)', 'Tilt(RNA)', 'Stacking_energy(RNA)', 'Twist(RNA)', 'Entropy(RNA)', 'Roll(RNA)', 'Enthalpy(RNA)1', 'Rise(RNA)', 'Free_energy(RNA)' , 'Shift(RNA)']
diPC_df = get_RNAPhyche(phy_list=di_phy_list, k=2, standardized=False)
diPC_df['kmer'] = diPC_df.index
diPC_df['kmer'] = diPC_df['kmer'].apply(kmer2number)
diPC_df = diPC_df.set_index('kmer')
            # print(diPC_df)

def get_correlationValue(diPC_df):
    correlationValue = np.zeros((len(diPC_df.columns), len(diPC_df), len(diPC_df)))
    for i in range(len(diPC_df.columns)):
        for j in range(len(diPC_df)):
            for k in range(len(diPC_df)):
                correlationValue[i, j, k] = (diPC_df.iloc[j, i] - diPC_df.iloc[k, i]) ** 2
    return correlationValue

def get_theta_array(seq, lambde, correlationValue):
    theta_array = []
    kmers = get_kmers(seq, 2)
    for ilambda in range(1, lambde + 1):
        theta = 0
        # for i in range(len(seq) - ilambda - 1):
        for i in range(len(seq) - lambde - 1):  # repDNA做法
            pepA = kmers[i]
            pepB = kmers[i + ilambda]

            CC = 0
            for j in range(len(correlationValue)):
                # print(j, pepA, pepB)
                CC += correlationValue[j, pepA, pepB]
                # print(correlationValue[j, pepA, pepB])
            CC /= len(correlationValue)
            theta += CC
        theta_array.append(theta / (len(seq) - ilambda - 1))
    return theta_array

def get_PseDNC_feature(seq, weight, lambde, correlationValue):
    '''
    特征维度为4**2+lambde
    :param seq:
    :param weight:
    :param lambde:
    :return:
    '''
    PseDNC_feature = []
    DNC_frequency = get_NC_frequency_from_seq(seq, k=2)
    theta_array = get_theta_array(seq, lambde, correlationValue=correlationValue)
    for i in range(4 ** 2):
        PseDNC_feature.append(DNC_frequency[i] / (1 + weight * sum(theta_array)))
    for i in range(4 ** 2 + 1, 4 ** 2 + lambde + 1):
        PseDNC_feature.append((weight * theta_array[i - 17]) / (1 + weight * sum(theta_array)))
    return PseDNC_feature

def analyze(temp, OutputDir):
    trainning_result, validation_result, testing_result = temp

    file = open(OutputDir + '/performance.txt', 'w')

    index = 0
    for x in [trainning_result, validation_result, testing_result]:


        title = ''

        if index == 0:
            title = 'training_'
        if index == 1:
            title = 'validation_'
        if index == 2:
            title = 'testing_'

        index += 1

        file.write(title +  'results\n')


        for j in ['sn', 'sp', 'acc', 'MCC', 'AUC', 'precision', 'F1', 'lossValue']:

            total = []

            for val in x:
                total.append(val[j])

            file.write(j + ' : mean : ' + str(np.mean(total)) + ' std : ' + str(np.std(total))  + '\n')

        file.write('\n\n______________________________\n')
    file.close()

    index = 0

    for x in [trainning_result, validation_result, testing_result]:

        tprs = []
        aucs = []
        mean_fpr = np.linspace(0, 1, 100)

        i = 0

        for val in x:
            tpr = val['tpr']
            fpr = val['fpr']
            tprs.append(interp(mean_fpr, fpr, tpr))
            tprs[-1][0] = 0.0
            roc_auc = auc(fpr, tpr)
            aucs.append(roc_auc)
            #plt.plot(fpr, tpr, lw=1, alpha=0.3,label='ROC fold %d (AUC = %0.2f)' % (i+1, roc_auc))

            i += 1

        print()

        plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r',label='Random', alpha=.8)

        mean_tpr = np.mean(tprs, axis=0)
        mean_tpr[-1] = 1.0

        dict_obj = {'data1': mean_fpr,'data2': mean_tpr}
        df_obj1 = pd.DataFrame(dict_obj)
        res_file = './bg5_mean_auc.xlsx'
        writer = pd.ExcelWriter(res_file)
        df_obj1.to_excel(writer, index=False, sheet_name='Sheet1')
        writer.save()

        mean_auc = auc(mean_fpr, mean_tpr)
        std_auc = np.std(aucs)
        plt.plot(mean_fpr, mean_tpr, color='b',
                 label=r'Mean ROC (AUC = %0.2f $\pm$ %0.2f)' % (mean_auc, std_auc),
                 lw=2, alpha=.8)

        std_tpr = np.std(tprs, axis=0)
        tprs_upper = np.minimum(mean_tpr + std_tpr, 1)
        tprs_lower = np.maximum(mean_tpr - std_tpr, 0)
        plt.fill_between(mean_fpr, tprs_lower, tprs_upper, color='grey', alpha=.2,
                         label=r'$\pm$ 1 std. dev.')

        plt.xlim([-0.05, 1.05])
        plt.ylim([-0.05, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Receiver operating characteristic curve')
        plt.legend(loc="lower right")

        title = ''

        if index == 0:
            title = 'training_'
        if index == 1:
            title = 'validation_'
        if index == 2:
            title = 'testing_'

        plt.savefig( OutputDir + '/' + title +'ROC.png')
        plt.close('all')

        index += 1

def chunkIt(seq, num):
    avg = len(seq) / float(num)
    out = []
    last = 0.0

    while last < len(seq):
        out.append(seq[int(last):int(last + avg)])
        last += avg
    
    return out

def calculate(sequence):

    X = []
    dictNum = {'A' : 0, 'U' : 0, 'C' : 0, 'G' : 0}

    for i in range(len(sequence)):

        if sequence[i] in list(dictNum.keys()):
            dictNum[sequence[i]] += 1
            X.append(dictNum[sequence[i]] / float(i + 1))

    return np.array(X)

def dataProcessing(path):

    data = pd.read_csv(path)
    alphabet = np.array(['A', 'G', 'U', 'C'])
    X = []
    for line in data['data']:
        line = list(line.strip('\n'));
        seq = np.array(line, dtype='|U1');
        seq_data = get_PseDNC_feature(seq, 0.2, 2, get_correlationValue(diPC_df))
        X.append(np.array(seq_data).reshape(18, 1))
    X = np.array(X);
    y = np.array(data['label'], dtype=np.int32);
    return X, y;

def prepareData(PositiveCSV, NegativeCSV):
    Positive_X, Positive_y = dataProcessing(PositiveCSV)
    Negitive_X, Negitive_y = dataProcessing(NegativeCSV)
    return Positive_X, Positive_y, Negitive_X, Negitive_y

def shuffleData(X, y):
    index = [i for i in range(len(X))]
    random.shuffle(index)
    X = X[index]
    y = y[index]
    return X, y

def attention_block_3(inputs,feature_cnt,dim):
    a = Flatten()(inputs)
    a = Dense(feature_cnt*dim,activation='softmax')(a)
    a = Reshape((feature_cnt,dim,))(a)
    a = Lambda(lambda x: K.backend.sum(x, axis=2), name='attention')(a)
    a = RepeatVector(dim)(a)
    a_probs = Permute((2, 1), name='attention_vec')(a)
    attention_out = Multiply()([inputs, a_probs])
    return attention_out

nb_lstm_outputs = 32
nb_time_steps = 18
nb_input_vectors = 1

def creat_model():

    input_shape = (18, 1)
    input = Input(shape=input_shape)
    gruLayer =Bidirectional(GRU(units=32, return_sequences=True),input_shape=(18, 1))(input)
    #attention_mul=attention_block_3(gruLayer,41,64)
    flattenLayer=Flatten()(gruLayer)
    dropoutLayer = Dropout(0.25)(flattenLayer)
    outLayer = Dense(units=1,activation='sigmoid')(dropoutLayer)
    model = Model(inputs=input, outputs=outLayer)
    model.compile(loss='binary_crossentropy', optimizer=Adam(lr=0.005), metrics=[binary_accuracy])
    print(model.summary())
    return model

def calculateScore(X, y, model):
    
    score = model.evaluate(X,y)
    pred_y = model.predict(X)

    accuracy = score[1]

    tempLabel = np.zeros(shape = y.shape, dtype=np.int32)

    for i in range(len(y)):
        if pred_y[i] < 0.5:
            tempLabel[i] = 0
        else:
            tempLabel[i] = 1
    confusion = confusion_matrix(y, tempLabel)
    TN, FP, FN, TP = confusion.ravel()

    sensitivity = recall_score(y, tempLabel)
    specificity = TN / float(TN+FP)
    MCC = matthews_corrcoef(y, tempLabel)

    F1Score = (2 * TP) / float(2 * TP + FP + FN)
    precision = TP / float(TP + FP)

    pred_y = pred_y.reshape((-1, ))

    ROCArea = roc_auc_score(y, pred_y)
    fpr, tpr, thresholds = roc_curve(y, pred_y)
    lossValue = None

    print((y.shape))
    print((pred_y.shape))

    y_true = tf.convert_to_tensor(y, np.float32)
    y_pred = tf.convert_to_tensor(pred_y, np.float32)

    with tf.Session():
        lossValue = losses.binary_crossentropy(y_true, y_pred).eval()

    return {'sn' : sensitivity, 'sp' : specificity, 'acc' : accuracy, 'MCC' : MCC, 'AUC' : ROCArea, 'precision' : precision, 'F1' : F1Score, 'fpr' : fpr, 'tpr' : tpr, 'thresholds' : thresholds, 'lossValue' : lossValue}

def funciton(PositiveCSV, NegativeCSV, OutputDir, folds):

    Positive_X, Positive_y, Negitive_X, Negitive_y = prepareData(PositiveCSV, NegativeCSV)

    random.shuffle(Positive_X)
    random.shuffle(Negitive_X)

    Positive_X_Slices = chunkIt(Positive_X, folds)
    Positive_y_Slices = chunkIt(Positive_y, folds)

    Negative_X_Slices = chunkIt(Negitive_X, folds)
    Negative_y_Slices = chunkIt(Negitive_y, folds)

    trainning_result = []
    validation_result = []
    testing_result = []
    
    for test_index in range(folds):

        test_X = np.concatenate((Positive_X_Slices[test_index],Negative_X_Slices[test_index]))
        test_y = np.concatenate((Positive_y_Slices[test_index],Negative_y_Slices[test_index]))

        validation_index = (test_index+1) % folds

        valid_X = np.concatenate((Positive_X_Slices[validation_index],Negative_X_Slices[validation_index]))
        valid_y = np.concatenate((Positive_y_Slices[validation_index],Negative_y_Slices[validation_index]))

        start = 0

        for val in range(0, folds):
            if val != test_index and val != validation_index:
                start = val
                break

        train_X = np.concatenate((Positive_X_Slices[start],Negative_X_Slices[start]))
        train_y = np.concatenate((Positive_y_Slices[start],Negative_y_Slices[start]))

        for i in range(0, folds):
            if i != test_index and i != validation_index and i != start:
                tempX = np.concatenate((Positive_X_Slices[i],Negative_X_Slices[i]))
                tempy = np.concatenate((Positive_y_Slices[i],Negative_y_Slices[i]))

                train_X = np.concatenate((train_X, tempX))
                train_y = np.concatenate((train_y, tempy))

        test_X, test_y = shuffleData(test_X,test_y)
        valid_X,valid_y = shuffleData(valid_X,valid_y)
        train_X,train_y = shuffleData(train_X,train_y)


        model = creat_model()
        early_stopping = EarlyStopping(monitor='val_binary_accuracy', patience= 30)
        model_check = ModelCheckpoint(filepath = OutputDir + "/model" + str(test_index+1) +".h5", monitor = 'val_binary_accuracy', save_best_only=True)
        reduct_L_rate = ReduceLROnPlateau(monitor='val_loss',factor=0.1, patience=20)
        history = model.fit(train_X, train_y, batch_size = 32, epochs = 150, validation_data = (valid_X, valid_y),callbacks = [model_check, early_stopping,reduct_L_rate])
        trainning_result.append(calculateScore(train_X, train_y, model))
        validation_result.append(calculateScore(valid_X, valid_y, model))
        testing_result.append(calculateScore(test_X, test_y, model))

    temp_dict = (trainning_result, validation_result, testing_result)
    analyze(temp_dict, OutputDir)

def main():

    parser = argparse.ArgumentParser(description="deep learning m5c analysis")

    parser.add_argument("--output", type=str, help="output folder", required=True)
    parser.add_argument("--positive", type=str, help="positive m5c csv", required=True)
    parser.add_argument("--negative", type=str, help="negative m5c csv", required=True)
    args = parser.parse_args()

    PositiveCSV = os.path.abspath(args.positive)
    NegativeCSV = os.path.abspath(args.negative)
    OutputDir = os.path.abspath(args.output)

    if not os.path.exists(OutputDir):
        print("The OutputDir not exist! Error\n")
        sys.exit()
    if not os.path.exists(PositiveCSV) or not os.path.exists(NegativeCSV):
        print("The csv data not exist! Error\n")
        sys.exit()

    funciton(PositiveCSV, NegativeCSV, OutputDir, 10)

if __name__ == "__main__":
    main()


